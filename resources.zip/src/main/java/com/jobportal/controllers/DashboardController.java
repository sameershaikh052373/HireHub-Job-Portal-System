package com.jobportal.controllers;

import com.jobportal.models.Job;
import com.jobportal.models.JobApplication;
import com.jobportal.models.User;
import com.jobportal.services.JobApplicationService;
import com.jobportal.services.JobService;
import com.jobportal.services.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class DashboardController {
    
    private final UserService userService;
    private final JobService jobService;
    private final JobApplicationService applicationService;

    public DashboardController(UserService userService, JobService jobService, JobApplicationService applicationService) {
        this.userService = userService;
        this.jobService = jobService;
        this.applicationService = applicationService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findUserByEmail(auth.getName());
        
        model.addAttribute("user", user);
        
        if (user.getUserType() == User.UserType.JOB_SEEKER) {
            return jobSeekerDashboard(model, user);
        } else if (user.getUserType() == User.UserType.EMPLOYER) {
            return employerDashboard(model, user);
        } else if (user.getUserType() == User.UserType.ADMIN) {
            return adminDashboard(model, user);
        }
        
        return "dashboard/index";
    }
    
    private String jobSeekerDashboard(Model model, User jobSeeker) {
        // Get recent applications
        List<JobApplication> applications = applicationService.findApplicationsByApplicant(jobSeeker);
        model.addAttribute("applications", applications);
        
        // Get recommended jobs (can be enhanced with actual job recommendation algorithm)
        List<Job> recommendedJobs = jobService.findActiveJobs();
        model.addAttribute("recommendedJobs", recommendedJobs);
        
        return "dashboard/jobseeker";
    }
    
    private String employerDashboard(Model model, User employer) {
        // Get employer's jobs
        List<Job> jobs = jobService.findJobsByEmployer(employer);
        model.addAttribute("jobs", jobs);
        
        // Count total applications across all jobs
        int totalApplications = 0;
        for (Job job : jobs) {
            List<JobApplication> applications = applicationService.findApplicationsByJob(job);
            totalApplications += applications.size();
        }
        model.addAttribute("totalApplications", totalApplications);
        
        return "dashboard/employer";
    }
    
    private String adminDashboard(Model model, User admin) {
        // Get all users count
        long totalUsers = userService.findAllUsers().size();
        model.addAttribute("totalUsers", totalUsers);
        
        // Get job seekers count
        long jobSeekersCount = userService.findAllJobSeekers().size();
        model.addAttribute("jobSeekersCount", jobSeekersCount);
        
        // Get employers count
        long employersCount = userService.findAllEmployers().size();
        model.addAttribute("employersCount", employersCount);
        
        // Get active jobs count
        long activeJobsCount = jobService.findActiveJobs().size();
        model.addAttribute("activeJobsCount", activeJobsCount);
        
        return "dashboard/admin";
    }
    
    @GetMapping("/profile")
    public String profile(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findUserByEmail(auth.getName());
        
        model.addAttribute("user", user);
        
        if (user.getUserType() == User.UserType.JOB_SEEKER) {
            return "profile/jobseeker";
        } else if (user.getUserType() == User.UserType.EMPLOYER) {
            return "profile/employer";
        }
        
        return "profile/index";
    }
}