package com.jobportal.controllers;

import com.jobportal.models.Job;
import com.jobportal.models.JobApplication;
import com.jobportal.models.User;
import com.jobportal.services.JobApplicationService;
import com.jobportal.services.JobService;
import com.jobportal.services.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Controller
public class JobApplicationController {
    
    private final JobApplicationService applicationService;
    private final JobService jobService;
    private final UserService userService;

    public JobApplicationController(JobApplicationService applicationService, JobService jobService, UserService userService) {
        this.applicationService = applicationService;
        this.jobService = jobService;
        this.userService = userService;
    }

    @GetMapping("/jobs/{jobId}/apply")
    public String applyForm(@PathVariable Long jobId, Model model) {
        Job job = jobService.findJobById(jobId);
        
        // Check if job is active
        if (job.getStatus() != Job.JobStatus.ACTIVE) {
            return "redirect:/jobs/" + jobId + "?error=job-closed";
        }
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User applicant = userService.findUserByEmail(auth.getName());
        
        // Check if user is a job seeker
        if (applicant.getUserType() != User.UserType.JOB_SEEKER) {
            return "redirect:/jobs/" + jobId + "?error=not-job-seeker";
        }
        
        // Check if user already applied
        if (applicationService.hasApplied(job, applicant)) {
            return "redirect:/jobs/" + jobId + "?error=already-applied";
        }
        
        JobApplication application = new JobApplication();
        application.setJob(job);
        application.setApplicant(applicant);
        
        model.addAttribute("job", job);
        model.addAttribute("application", application);
        
        return "applications/apply";
    }
    
    @PostMapping("/jobs/{jobId}/apply")
    public String submitApplication(@PathVariable Long jobId, 
                                   @ModelAttribute JobApplication application,
                                   @RequestParam("resumeFile") MultipartFile resumeFile,
                                   RedirectAttributes redirectAttributes) {
        
        Job job = jobService.findJobById(jobId);
        
        // Check if job is active
        if (job.getStatus() != Job.JobStatus.ACTIVE) {
            return "redirect:/jobs/" + jobId + "?error=job-closed";
        }
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User applicant = userService.findUserByEmail(auth.getName());
        
        // Check if user already applied
        if (applicationService.hasApplied(job, applicant)) {
            return "redirect:/jobs/" + jobId + "?error=already-applied";
        }
        
        application.setJob(job);
        application.setApplicant(applicant);
        
        // Handle resume file upload
        if (!resumeFile.isEmpty()) {
            try {
                // Create directory for resume uploads if it doesn't exist
                String uploadsDir = "uploads/resumes/";
                Path uploadPath = Paths.get(uploadsDir);
                
                if (!Files.exists(uploadPath)) {
                    Files.createDirectories(uploadPath);
                }
                
                // Generate unique filename
                String filename = UUID.randomUUID().toString() + "_" + resumeFile.getOriginalFilename();
                Path filePath = uploadPath.resolve(filename);
                
                // Save file
                Files.copy(resumeFile.getInputStream(), filePath);
                
                // Set resume path in application
                application.setResumePath(uploadsDir + filename);
                
            } catch (IOException e) {
                redirectAttributes.addFlashAttribute("error", "Failed to upload resume: " + e.getMessage());
                return "redirect:/jobs/" + jobId + "/apply";
            }
        }
        
        applicationService.createApplication(application);
        redirectAttributes.addFlashAttribute("success", "Application submitted successfully!");
        
        return "redirect:/jobseeker/applications";
    }
    
    @GetMapping("/jobseeker/applications")
    public String listJobSeekerApplications(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User applicant = userService.findUserByEmail(auth.getName());
        
        List<JobApplication> applications = applicationService.findApplicationsByApplicant(applicant);
        model.addAttribute("applications", applications);
        
        return "applications/my-applications";
    }
    
    @GetMapping("/employer/jobs/{jobId}/applications")
    public String listJobApplications(@PathVariable Long jobId, Model model) {
        Job job = jobService.findJobById(jobId);
        
        // Verify that the current user is the job's employer
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!job.getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        List<JobApplication> applications = applicationService.findApplicationsByJob(job);
        model.addAttribute("applications", applications);
        model.addAttribute("job", job);
        
        return "applications/job-applications";
    }
    
    @GetMapping("/employer/applications/{id}")
    public String viewApplication(@PathVariable Long id, Model model) {
        JobApplication application = applicationService.findApplicationById(id);
        
        // Verify that the current user is the employer for this application
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!application.getJob().getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        model.addAttribute("application", application);
        
        return "applications/view";
    }
    
    @PostMapping("/employer/applications/{id}/update-status")
    public String updateApplicationStatus(@PathVariable Long id, 
                                         @RequestParam JobApplication.ApplicationStatus status,
                                         RedirectAttributes redirectAttributes) {
        
        JobApplication application = applicationService.findApplicationById(id);
        
        // Verify that the current user is the employer for this application
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!application.getJob().getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        applicationService.updateApplicationStatus(id, status);
        redirectAttributes.addFlashAttribute("success", "Application status updated successfully!");
        
        return "redirect:/employer/jobs/" + application.getJob().getId() + "/applications";
    }
}