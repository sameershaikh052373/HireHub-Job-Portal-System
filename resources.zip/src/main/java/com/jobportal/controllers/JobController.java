package com.jobportal.controllers;

import com.jobportal.models.Job;
import com.jobportal.models.JobApplication;
import com.jobportal.models.User;
import com.jobportal.services.JobApplicationService;
import com.jobportal.services.JobService;
import com.jobportal.services.UserService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@Controller
public class JobController {
    
    private final JobService jobService;
    private final UserService userService;
    private final JobApplicationService applicationService;

    public JobController(JobService jobService, UserService userService, JobApplicationService applicationService) {
        this.jobService = jobService;
        this.userService = userService;
        this.applicationService = applicationService;
    }

    @GetMapping("/jobs")
    public String listJobs(Model model, 
                          @RequestParam(defaultValue = "0") int page,
                          @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<Job> jobPage = jobService.findAllJobs(pageable);
        
        model.addAttribute("jobs", jobPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", jobPage.getTotalPages());
        model.addAttribute("totalItems", jobPage.getTotalElements());
        
        return "jobs/list";
    }
    
    @GetMapping("/jobs/search")
    public String searchJobs(Model model, 
                            @RequestParam(required = false) String keyword,
                            @RequestParam(required = false) String location) {
        List<Job> searchResults;
        
        if (keyword != null && !keyword.isEmpty() && location != null && !location.isEmpty()) {
            searchResults = jobService.searchJobsByKeywordAndLocation(keyword, location);
        } else if (keyword != null && !keyword.isEmpty()) {
            searchResults = jobService.searchJobs(keyword);
        } else if (location != null && !location.isEmpty()) {
            searchResults = jobService.findJobsByLocation(location);
        } else {
            searchResults = jobService.findActiveJobs();
        }
        
        model.addAttribute("jobs", searchResults);
        model.addAttribute("keyword", keyword);
        model.addAttribute("location", location);
        
        return "jobs/search-results";
    }
    
    @GetMapping("/jobs/{id}")
    public String viewJob(@PathVariable Long id, Model model) {
        Job job = jobService.findJobById(id);
        model.addAttribute("job", job);
        
        // Check if the current user has applied for this job
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !auth.getName().equals("anonymousUser")) {
            try {
                User currentUser = userService.findUserByEmail(auth.getName());
                boolean hasApplied = applicationService.hasApplied(job, currentUser);
                model.addAttribute("hasApplied", hasApplied);
                model.addAttribute("isJobSeeker", currentUser.getUserType() == User.UserType.JOB_SEEKER);
                model.addAttribute("isEmployer", currentUser.getUserType() == User.UserType.EMPLOYER);
                model.addAttribute("isOwner", job.getEmployer().getId().equals(currentUser.getId()));
            } catch (Exception e) {
                model.addAttribute("hasApplied", false);
            }
        }
        
        return "jobs/view";
    }
    
    @GetMapping("/employer/jobs/create")
    public String createJobForm(Model model) {
        model.addAttribute("job", new Job());
        return "jobs/create";
    }
    
    @PostMapping("/employer/jobs/create")
    public String createJob(@Valid @ModelAttribute("job") Job job, BindingResult result) {
        if (result.hasErrors()) {
            return "jobs/create";
        }
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        job.setEmployer(employer);
        jobService.createJob(job);
        
        return "redirect:/employer/jobs";
    }
    
    @GetMapping("/employer/jobs")
    public String listEmployerJobs(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        List<Job> jobs = jobService.findJobsByEmployer(employer);
        model.addAttribute("jobs", jobs);
        
        return "jobs/employer-jobs";
    }
    
    @GetMapping("/employer/jobs/{id}/edit")
    public String editJobForm(@PathVariable Long id, Model model) {
        Job job = jobService.findJobById(id);
        
        // Verify that the current user is the job's employer
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!job.getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        model.addAttribute("job", job);
        return "jobs/edit";
    }
    
    @PostMapping("/employer/jobs/{id}/edit")
    public String updateJob(@PathVariable Long id, @Valid @ModelAttribute("job") Job updatedJob, 
                          BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "jobs/edit";
        }
        
        Job job = jobService.findJobById(id);
        
        // Verify that the current user is the job's employer
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!job.getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        // Update job fields
        job.setTitle(updatedJob.getTitle());
        job.setDescription(updatedJob.getDescription());
        job.setLocation(updatedJob.getLocation());
        job.setSalary(updatedJob.getSalary());
        job.setJobType(updatedJob.getJobType());
        job.setRequirements(updatedJob.getRequirements());
        job.setBenefits(updatedJob.getBenefits());
        job.setExpiresAt(updatedJob.getExpiresAt());
        
        jobService.updateJob(job);
        
        return "redirect:/employer/jobs";
    }
    
    @PostMapping("/employer/jobs/{id}/close")
    public String closeJob(@PathVariable Long id) {
        Job job = jobService.findJobById(id);
        
        // Verify that the current user is the job's employer
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!job.getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        jobService.closeJob(id);
        return "redirect:/employer/jobs";
    }
    
    @PostMapping("/employer/jobs/{id}/delete")
    public String deleteJob(@PathVariable Long id) {
        Job job = jobService.findJobById(id);
        
        // Verify that the current user is the job's employer
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User employer = userService.findUserByEmail(auth.getName());
        
        if (!job.getEmployer().getId().equals(employer.getId())) {
            return "redirect:/employer/jobs?error=unauthorized";
        }
        
        jobService.deleteJob(id);
        return "redirect:/employer/jobs";
    }
}