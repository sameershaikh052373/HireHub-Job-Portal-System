package com.jobportal.services;

import com.jobportal.models.Job;
import com.jobportal.models.JobApplication;
import com.jobportal.models.User;
import com.jobportal.repositories.JobApplicationRepository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class JobApplicationService {
    
    private final JobApplicationRepository applicationRepository;

    public JobApplicationService(JobApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }
    
    public JobApplication createApplication(JobApplication application) {
        application.setStatus(JobApplication.ApplicationStatus.APPLIED);
        application.setCreatedAt(LocalDateTime.now());
        return applicationRepository.save(application);
    }
    
    public JobApplication updateApplicationStatus(Long id, JobApplication.ApplicationStatus status) {
        JobApplication application = findApplicationById(id);
        application.setStatus(status);
        return applicationRepository.save(application);
    }
    
    public JobApplication findApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Application with id " + id + " not found"));
    }
    
    public List<JobApplication> findApplicationsByApplicant(User applicant) {
        return applicationRepository.findByApplicant(applicant);
    }
    
    public List<JobApplication> findApplicationsByJob(Job job) {
        return applicationRepository.findByJob(job);
    }
    
    public List<JobApplication> findApplicationsByJobAndStatus(Job job, JobApplication.ApplicationStatus status) {
        return applicationRepository.findByJobAndStatus(job, status);
    }
    
    public boolean hasApplied(Job job, User applicant) {
        return applicationRepository.existsByJobAndApplicant(job, applicant);
    }
    
    public void deleteApplication(Long id) {
        applicationRepository.deleteById(id);
    }
}